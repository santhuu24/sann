package com.cg.lab2;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {
	public static void main(String[] arg) {
		
		// need to call to create once only to create a tables
		  lab2_1();
		 
		
		Lab2_2 obj=new Lab2_2();
		obj.queryAllBook();
		//obj.queryAllBookByAuthor();
		//obj.priceRange();
		//obj.authorByBookId();
		
	}
	private static void lab2_1()
	{
		Book b1=new Book();
		Book b2=new Book();
		Author a1=new Author();
		
		b1.setIsbn(111);
		b1.setTitle("Harry potter and goblet of fire");
		b1.setPrice(599.0);
		
		b2.setIsbn(121);
		b2.setTitle("Harry potter and Half blood prince");
		b2.setPrice(599.0);
		
		a1.setId(1097);
		a1.setName("J.K. Rowling");
		
		a1.getBookList().add(b1);
		a1.getBookList().add(b2);
		
		b1.setAuthor(a1);
		b2.setAuthor(a1);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.persist(a1);
		entityManager.persist(b2);
		entityManager.persist(b1);
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
		
	}

}
