package com.cg.lab2;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Lab2_2 {

	public void queryAllBook()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		String strQuery="from Book";
		TypedQuery<Book> query=entityManager.createQuery(strQuery, Book.class);
		List<Book> bookList=query.getResultList();
		
		for (Book book : bookList) {
			System.out.println(book);
		}
		
		entityManager.close();
		emf.close();
		
	}
	
	public void queryAllBookByAuthor()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Author's Name");
		String aName=sc.nextLine();
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		String strQuery="from Author where name=:name";
		TypedQuery<Author> query=entityManager.createQuery(strQuery, Author.class);
		query.setParameter("name", aName);
		Author a=query.getSingleResult();
		for (Book b :  a.getBookList()) {
			System.out.println(b);
		}
		sc.close();
		entityManager.close();
		emf.close();
		
	}
	
	public void priceRange()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the starting value for price range");
		double begin=sc.nextInt();
		System.out.println("Enter the last value for price range");
		double end=sc.nextInt();
		
		String strQuery="from Book where price between :beg AND :end";
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		TypedQuery<Book> query=entityManager.createQuery(strQuery, Book.class);
		query.setParameter("beg",begin);
		query.setParameter("end",end);
		
		List<Book> bookList=query.getResultList();
		for (Book book : bookList) {
			System.out.println(book);
		}
		sc.close();
		entityManager.close();
		emf.close();
	}
	
	public void authorByBookId()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Book id");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		String strQuery="from Book where id=:book_id";
		TypedQuery<Book> query=entityManager.createQuery(strQuery, Book.class);
		query.setParameter("book_id",sc.nextInt());
		
		Book b1=query.getSingleResult();
		System.out.println("Author name is :"+b1.getAuthor().getName());
		sc.close();
		entityManager.close();
		emf.close();
	}
	
}
