package com.cg.lab2.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lab2.trainee.bean.Trainee;
import com.cg.lab2.trainee.exception.TraineeException;
import com.cg.lab2.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	ITraineeService traineeService;
	
	@RequestMapping("/login")
	public ModelAndView index(@RequestParam("userName")String uName,@RequestParam("password")String password)
	{
		if(uName.equalsIgnoreCase("Admin") && password.equals("Admin"))
		{
			return new ModelAndView("index");
		}
		else
		{
			return new ModelAndView("login","error","Invalid Usename/password");
		}
	
		
	}
	@RequestMapping("/add")
	public String addTrainee()
	{
		return "form";
	}
	@RequestMapping("insertT")
	public ModelAndView insertTrainee(@ModelAttribute("trainee") Trainee trainee)
	{
		try {
			traineeService.addTrainee(trainee);
			return new ModelAndView("index");
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
		
	}
	@RequestMapping("/fetch")
	public String fetchTrainee()
	{
		return "View";
	}
	@RequestMapping("/fetchB")
	public ModelAndView retrieveTraineeById(@RequestParam("id") int id)
	{
		try {
			Trainee trainee= traineeService.retrieveTraineeById(id);
			return new ModelAndView("View","trainee",trainee);
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
		
	}
	@RequestMapping("/fetchAll")
	public ModelAndView retrieveAllTrainee()
	{
		try {
			List<Trainee> traineeList= traineeService.retrieveAllTrainee();
			return new ModelAndView("viewAll","traineeList",traineeList);
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
		
	}
	@RequestMapping("/delete")
	public String deleteTraine()
	{
		return "remove";
	}
	@RequestMapping("/deleteB")
	public ModelAndView deleteTraineeById(@RequestParam("id") int id)
	{
		try {
			Trainee trainee= traineeService.retrieveTraineeById(id);
			return new ModelAndView("remove","trainee",trainee);
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
	}
	@RequestMapping("/deleteC")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") Trainee trainee)
	{
		try {
			traineeService.addTrainee(trainee);
			return new ModelAndView("index");
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
		
	}
	@RequestMapping("/update")
	public String updateTrainee()
	{
		return "change";
	}
	@RequestMapping("/updateB")
	public ModelAndView updateTraineeById(@RequestParam("id") int id)
	{
		try {
			Trainee trainee= traineeService.retrieveTraineeById(id);
			return new ModelAndView("change","trainee",trainee);
		} catch (TraineeException e) {
			return new ModelAndView("error","error",e.getMessage());
		}
		
	}

}
