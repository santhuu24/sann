package com.cg.lab2.trainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab2.trainee.bean.Trainee;
import com.cg.lab2.trainee.dao.ITraineeDao;
import com.cg.lab2.trainee.exception.TraineeException;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService{

	@Autowired
	ITraineeDao traineeDao;

	@Override
	public List<Trainee> addTrainee(Trainee trainee) throws TraineeException {
		
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public List<Trainee> retrieveAllTrainee() throws TraineeException {

		return traineeDao.retrieveAllTrainee();
	}

	@Override
	public Trainee retrieveTraineeById(int id) throws TraineeException {
		
		return traineeDao.retrieveTraineeById(id);
	}
}
