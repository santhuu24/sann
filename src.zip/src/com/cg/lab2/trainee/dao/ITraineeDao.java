package com.cg.lab2.trainee.dao;

import java.util.List;

import com.cg.lab2.trainee.bean.Trainee;
import com.cg.lab2.trainee.exception.TraineeException;

public interface ITraineeDao {
	public List<Trainee> addTrainee(Trainee trainee) throws TraineeException;
	public List<Trainee> retrieveAllTrainee() throws TraineeException;
	public Trainee retrieveTraineeById(int id) throws TraineeException;
}
