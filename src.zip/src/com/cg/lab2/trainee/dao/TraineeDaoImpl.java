package com.cg.lab2.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.lab2.trainee.bean.Trainee;
import com.cg.lab2.trainee.exception.TraineeException;
@Repository
public class TraineeDaoImpl implements ITraineeDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Trainee> addTrainee(Trainee trainee) throws TraineeException {
		List<Trainee> traineeList=null;
		try {
			entityManager.persist(trainee);
			traineeList=retrieveAllTrainee();
		}catch (Exception e) {
			throw new TraineeException(e.getMessage());
		}
		return traineeList;
		
	}

	@Override
	public List<Trainee> retrieveAllTrainee() throws TraineeException {
		List<Trainee> traineeList=null;
		try {
			String strQuery="from Trainee";
			TypedQuery<Trainee> query=entityManager.createQuery(strQuery, Trainee.class);
			traineeList=query.getResultList();
		}catch (Exception e) {
			throw new TraineeException(e.getMessage());
		}
		return traineeList;
		
	}

	@Override
	public Trainee retrieveTraineeById(int id) throws TraineeException {
		try {
			String strQuery="from Trainee where traineeId=:id";
			TypedQuery<Trainee> query=entityManager.createQuery(strQuery, Trainee.class);
			query.setParameter("id",id);
			Trainee trainee=query.getSingleResult();
			return trainee;
		}catch (Exception e) {
			throw new TraineeException(e.getMessage());
		}
		
	}

}
