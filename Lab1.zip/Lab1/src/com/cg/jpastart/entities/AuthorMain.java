package com.cg.jpastart.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorMain {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] ar) {
		
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=emf.createEntityManager();
		int ch=0;
		Author a=null;
		do
		{
			
			entityManager.getTransaction().begin();
			System.out.println("Press 1 for insert \n2 for update\n3 for delete \n4 for exit");
			ch=sc.nextInt();
			switch(ch)
			{
				case 1:
				
					a=insertMethod();
					entityManager.persist(a);
					break;
				
				case 2:
					System.out.println("Enter Author Id for updatation");
					Author x =entityManager.find(Author.class, sc.nextInt());
					entityManager.merge(update(x));
					break;
				
				case 3:
					System.out.println("Enter Author's Id To delete");
					Author y=entityManager.find(Author.class, sc.nextInt());
					entityManager.remove(y);
					
					break;
				
				case 4:
				{
					System.out.println("Thank you!!");
					System.exit(0);
					break;
				}
		
			}	
			entityManager.getTransaction().commit();
		}while(ch!=4);
		
		entityManager.close();
		emf.close();
	}

	private static Author update(Author a) {
		System.out.println("press 1 to update first name \npress 2 to update Middle name \npress 3 to update last name \npress 4 to update Phone Number");
		int op=sc.nextInt();
		switch(op)
		{
			case 1:System.out.println("Enter Author's First Name");
				a.setFirstName(sc.next());
				break;
			case 2:System.out.println("Enter Author's Middle Name");
				a.setMiddleName(sc.next());
			break;
			case 3:	System.out.println("Enter Author's last Name");
				a.setLastName(sc.next());
			break;
			case 4:System.out.println("Enter Author's Phone Number");
				a.setPhoneNo(sc.nextLong());
			break;
			default:
				System.out.println("invalid Choice");
		}
		return a;
	}

	private static Author insertMethod() {
		Author a1=new Author();
		System.out.println("Enter Author Id");
		a1.setAuthorId(sc.nextInt());
		System.out.println("Enter Author's First Name");
		a1.setFirstName(sc.next());
		System.out.println("Enter Author's Middle Name");
		a1.setMiddleName(sc.next());
		System.out.println("Enter Author's last Name");
		a1.setLastName(sc.next());
		System.out.println("Enter Author's Phone Number");
		a1.setPhoneNo(sc.nextLong());
		return a1;
	}

}
