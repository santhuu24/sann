package com.cg.lab2.dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.lab2.bean.Product;
import com.cg.lab2.exception.ProductException;
import com.cg.lab2.staticDb.ProductDb;


public class ProductDaoImpl implements IProductDao {

	static HashMap<Integer,Product> productMap =null;
	public ProductDaoImpl() {
		 productMap = ProductDb.getProductMap();
	}
	@Override
	public double getPrice(String productName) throws ProductException {
		Product p= productMap.get(productName);
		return p.getProdPrice();
	}

	@Override
	public List<Product> getAllProducts() {
		
		List<Product> products = new ArrayList<Product>(productMap.values());
		return products;
	}

	

}
