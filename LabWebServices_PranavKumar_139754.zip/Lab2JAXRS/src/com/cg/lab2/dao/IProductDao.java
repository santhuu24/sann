package com.cg.lab2.dao;

import java.util.List;

import com.cg.lab2.bean.Product;
import com.cg.lab2.exception.ProductException;

public interface IProductDao {

	double getPrice(String productName) throws ProductException;
	public List<Product> getAllProducts();
}
