package com.cg.lab2.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.lab2.bean.Product;
import com.cg.lab2.service.IProductService;
import com.cg.lab2.service.ProductService;

@Path("/products")
public class ProductController {
	IProductService proSer;
	public ProductController() {
		 proSer=new ProductService();
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getCountries() {
		List<Product> listOfProducts = proSer.getAllProducts();
		return listOfProducts;
	}
	
}
