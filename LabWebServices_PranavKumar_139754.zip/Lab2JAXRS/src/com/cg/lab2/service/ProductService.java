package com.cg.lab2.service;

import java.util.List;



import com.cg.lab2.bean.Product;
import com.cg.lab2.dao.IProductDao;
import com.cg.lab2.dao.ProductDaoImpl;
import com.cg.lab2.exception.ProductException;


public class ProductService implements IProductService{
	IProductDao proDao;
	public ProductService() {
		proDao=new ProductDaoImpl();
	}

	@Override
	public double getProductPrice(String productName)
	{
		double price=0.0;
		try {
			price= proDao.getPrice(productName);
		} catch (ProductException e) {
			
			System.out.println("Product does not exsits");
		}
		return price;
	}

	@Override
	public List<Product> getAllProducts() {
		
		return proDao.getAllProducts();
	}
}
