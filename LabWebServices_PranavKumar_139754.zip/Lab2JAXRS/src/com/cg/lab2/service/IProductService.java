package com.cg.lab2.service;

import java.util.List;

import com.cg.lab2.bean.Product;

public interface IProductService {

	public double getProductPrice(String productName);
	
	public List<Product> getAllProducts();
	

}
