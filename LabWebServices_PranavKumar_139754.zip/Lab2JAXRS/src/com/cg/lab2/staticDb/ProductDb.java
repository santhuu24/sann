package com.cg.lab2.staticDb;

import java.util.HashMap;

import com.cg.lab2.bean.Product;

/**************************************************************
 * class Name - ProductDb
 * @author    - Pranav Kumar
 * Date		  - 21 dec,2017
 * desc		  - Static Database used for have a list of products
 ***************************************************************/
public class ProductDb {

	static HashMap<Integer,Product> productMap = getProductMap();
	
	static {
		if (productMap == null) {
			productMap = new HashMap<Integer, Product>();
			Product p1 = new Product(101,"Laptop",45678.34);
			Product p2 = new Product(102,"IPad",65678.84);
			Product p3 = new Product(103,"IPhone",84678.34);
			Product p4 = new Product(104,"IPod",1200.99);
			Product p5 = new Product(105,"Hard Disk",5000.0);
			Product p6 = new Product(106,"Data Cabies",2000.15);
			Product p7 = new Product(107,"Fit Bit Wrist Band",5000.78);
			Product p8 = new Product(108,"Arm Sleeves",500.12);
			Product p9 = new Product(109,"Adapter",4000.26);
			Product p0 = new Product(110,"Samsung Tab",75678.0);
			Product p = new Product(234,"DVD",345323.0);
			
			productMap.put(p1.getProdId(), p1);
			productMap.put(p2.getProdId(), p2);
			productMap.put(p3.getProdId(), p3);
			productMap.put(p4.getProdId(), p4);
			productMap.put(p5.getProdId(), p5);
			productMap.put(p6.getProdId(), p6);
			productMap.put(p7.getProdId(), p7);
			productMap.put(p8.getProdId(), p8);
			productMap.put(p9.getProdId(), p9);
			productMap.put(p0.getProdId(), p0);
			productMap.put(p.getProdId(), p);
			
		}
	}
	
	public static HashMap<Integer, Product> getProductMap() {
		return productMap;
	}

}
