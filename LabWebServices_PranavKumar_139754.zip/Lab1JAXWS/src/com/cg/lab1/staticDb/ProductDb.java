package com.cg.lab1.staticDb;

import java.util.HashMap;

import com.cg.lab1.bean.Product;



public class ProductDb {

	static HashMap<String,Product> productMap = getProductMap();
	
	static {
		if (productMap == null) {
			productMap = new HashMap<String, Product>();
			Product p1 = new Product("Mobile",5699.0);
			Product p2 = new Product("Watch",1699.0);
			Product p3 = new Product("EarPhone",599.0);
			productMap.put(p1.getProductName(), p1);
			productMap.put(p2.getProductName(), p2);
			productMap.put(p3.getProductName(), p3);
		}
	}
	
	public static HashMap<String, Product> getProductMap() {
		return productMap;
	}

}
