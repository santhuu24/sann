package com.cg.lab1.view;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.lab1.service.IProductService;


public class Client {
	public static void main(String[] args) throws MalformedURLException {
		
	
		System.out.println("Enter Product's Name");
		Scanner sc=new Scanner(System.in);
		String s= sc.next();
		
		URL url=new URL("http://localhost:9866/cs?wsdl");
		QName qname=new QName("http://service.lab1.cg.com/","ProductServiceService");
		Service service=Service.create(url,qname);
		IProductService sever=service.getPort(IProductService.class);
		try
		{
		System.out.println("Price of product is : "+sever.getProductPrice(s));
		}
		catch(Throwable e)
		{
			System.out.println("Product does not exists!!");
		}
		sc.close();
	}

}
