package com.cg.lab1.view;

import java.util.Date;

import javax.xml.ws.Endpoint;

import com.cg.lab1.service.ProductService;

public class ProductPublish {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:9866/cs",new ProductService());
		System.out.println("published on "+new Date());
	}

}
