package com.cg.lab1.dao;

import com.cg.lab1.exception.ProductException;

public interface IProductDao {

	double getPrice(String productName) throws ProductException;
}
