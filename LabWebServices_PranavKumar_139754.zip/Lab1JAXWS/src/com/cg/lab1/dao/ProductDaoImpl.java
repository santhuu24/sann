package com.cg.lab1.dao;


import java.util.HashMap;

import com.cg.lab1.bean.Product;
import com.cg.lab1.exception.ProductException;
import com.cg.lab1.staticDb.ProductDb;

public class ProductDaoImpl implements IProductDao {

	@Override
	public double getPrice(String productName) throws ProductException {
		HashMap<String,Product> productMap = ProductDb.getProductMap();
		Product p= productMap.get(productName);
		return p.getProductPrice();
	}

}
