package com.cg.lab1.service;

import javax.jws.WebService;

import com.cg.lab1.dao.ProductDaoImpl;


@WebService(endpointInterface="com.cg.lab1.service.IProductService")
public class ProductService {

	public double getProductPrice(String productName)
	{
		double price=0.0;
		try {
			price= new ProductDaoImpl().getPrice(productName);
		} catch (Exception e) {
			
			System.out.println("Product does not exsits");
		}
		return price;
	}
}
